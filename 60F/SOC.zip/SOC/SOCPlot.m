clear; clc; close all;

% Define the root folder where all SOC subfolders are located
rootFolder = pwd;

% Get a list of all SOC subfolders
socFolders = dir(fullfile(rootFolder, '*%SOC'));

% Sort SOC folders by descending SOC value to match the color scheme
[~, order] = sort(cellfun(@(x) str2double(regexp(x, '\d+', 'match', 'once')), {socFolders.name}), 'descend');
socFolders = socFolders(order);

% Initialize the plot standards
PS = PLOT_STANDARDS();
fig1_comps.fig = gcf;
fontSize = 20;

% Define the custom colors based on the provided palette
colors = {PS.DRed4, PS.DOrange2, PS.MyGreen4, PS.Blue1, PS.MyBlue4, PS.DBlue1}; 

% Initialize markers
markers = {'o', 's', 'd', '^', 'v', 'x'};  % Customize markers as needed

% Initialize the figure
hold on;

% Initialize variables to track min y value and max x value
min_y_value = inf;
max_x_value = -inf;
min_x_value = inf;

% Extract the number before "F" from the file path
tokens = regexp(rootFolder, '(\d+)F', 'tokens');
if ~isempty(tokens)
    capNumber = tokens{1}{1};
else
    capNumber = 'Unknown';
end

% Loop through each SOC folder to read and plot data
for k = 1:length(socFolders)
    % Get the current SOC subfolder path
    socFolderPath = fullfile(rootFolder, socFolders(k).name);
    
    % Construct the expected filename
    tokens = regexp(socFolders(k).name, '(\d+)%SOC', 'tokens');
    if ~isempty(tokens)
        SOC = str2double(tokens{1}{1});
        inputFile = fullfile(socFolderPath, sprintf('60F-%d%%SOC_Python.csv', SOC));
    else
        warning('No valid SOC percentage found in the folder name: %s', socFolders(k).name);
        continue;
    end
    
    % Check if the file exists
    if ~isfile(inputFile)
        warning('CSV file not found: %s', inputFile);
        continue;
    end
    
    % Read the measured data file
    data = readmatrix(inputFile);
    
    % Extract the relevant columns (assuming columns 2 and 3 are real and imaginary parts)
    real_part = data(:, 2);
    imaginary_part = data(:, 3);
    
    % Update min_y_value and max_x_value
    min_y_value = min(min_y_value, min(imaginary_part));
    max_x_value = max(max_x_value, max(real_part));
    min_x_value = min(min_x_value, min(real_part));
    
    % Plot the measured data
    plot(real_part, imaginary_part, 'LineStyle', '--', 'LineWidth', 3, ...
        'Marker', markers{k}, 'MarkerSize', 8, ...
        'MarkerFaceColor', colors{k}, 'MarkerEdgeColor', colors{k}, 'Color', colors{k});
end

% Customize the figure
xlabel('Real Part [$\Omega$]', 'Interpreter', 'latex', 'FontSize', fontSize); % Updated to milliohms
ylabel('-Imaginary Part [$\Omega$]', 'Interpreter', 'latex', 'FontSize', fontSize);
title(sprintf('Nyquist Plot for Different SOC Levels (%sF)', capNumber), 'FontSize', fontSize);
grid on;
ylim([min_y_value, 0]);
xlim([min_x_value, max_x_value]);

% Set axis properties
set(gca, 'YDir', 'reverse', 'FontSize', fontSize, 'LineWidth', 1.5, 'GridColor', 'k', 'GridAlpha', 0.6);
set(gca, 'XColor', 'k', 'YColor', 'k'); % Set tick color
set(gca, 'XTickLabel', get(gca, 'XTickLabel'), 'YTickLabel', get(gca, 'YTickLabel'));
set(gcf, 'Color', 'w');
ax = gca;
ax.GridColor = [0, 0, 0];
ax.GridAlpha = 0.6;
ax.LineWidth = 2;


% Add legend
legend(arrayfun(@(x) [num2str(x), '% SOC'], cellfun(@(x) str2double(regexp(x, '\d+', 'match')), {socFolders.name}), 'UniformOutput', false), 'Location', 'northwest', 'FontSize', fontSize);

% Standardize the figure
STANDARDIZE_FIGURE(fig1_comps);

SAVE_MY_FIGURE(fig1_comps, 'Figures/SOC60F.pdf', 'big');

% Display the tracked min and max values
disp(['Minimum y (imaginary part) value: ', num2str(min_y_value)]);
disp(['Maximum x (real part) value: ', num2str(max_x_value)]);
